# AWS-Lab-Building-a-Highly-Available-Scalable-Web-Application
AWS Lab: Building a Highly Available, Scalable Web Application

### Các file Javascript chứa mã nguồn của web-app có thể tải từ repo này.

### Hướng dẫn deploy web-app:
1. Trong bước tạo virtual machine đầu tiên thực hiện ở EC2, thêm mã Javascript từ file "UserdataScript-phase-2.sh" vào phần "User data".
2. Trong bước tạo virtual machine thứ hai thực hiện ở EC2, thêm mã Javascript từ file "UserdataScript-phase-3.sh" vào phần "User data".
